function showDocument(input) {
    if (input.height != 600) {
        input.height = 600
    } else {
        input.height = 0
    }
}
;
